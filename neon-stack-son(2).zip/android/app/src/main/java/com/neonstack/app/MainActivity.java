package com.neonstack.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
