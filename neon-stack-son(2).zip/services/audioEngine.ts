/**
 * Audio Engine for Synthwave Sound Effects
 * Optimized for persistent game sessions.
 */
class AudioEngine {
  private ctx: AudioContext | null = null;
  private gainNode: GainNode | null = null;
  private musicGainNode: GainNode | null = null;
  private isInitialized: boolean = false;
  private musicOsc: OscillatorNode | null = null;
  private musicFilter: BiquadFilterNode | null = null;

  private scale = [0, 2, 4, 7, 9]; // Pentatonic

  constructor() {}

  public init() {
    if (this.isInitialized && this.ctx) return;

    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();
      
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.value = 0.25;
      this.gainNode.connect(this.ctx.destination);

      this.musicGainNode = this.ctx.createGain();
      this.musicGainNode.gain.value = 0.1;
      this.musicGainNode.connect(this.ctx.destination);
      
      this.isInitialized = true;
    } catch (e) {
      console.warn("AudioContext failed to initialize", e);
    }
  }

  public setSoundVolume(value: number) {
    if (this.gainNode) this.gainNode.gain.value = value;
  }

  public setMusicVolume(value: number) {
    if (this.musicGainNode) this.musicGainNode.gain.value = value;
  }

  public startMusic() {
    if (!this.ctx || !this.musicGainNode || this.musicOsc) return;
    this.resume();
    
    const now = this.ctx.currentTime;
    this.musicOsc = this.ctx.createOscillator();
    this.musicFilter = this.ctx.createBiquadFilter();
    
    this.musicOsc.type = 'triangle';
    this.musicOsc.frequency.setValueAtTime(55, now); // Low A
    
    this.musicFilter.type = 'lowpass';
    this.musicFilter.frequency.setValueAtTime(400, now);
    
    const lfo = this.ctx.createOscillator();
    const lfoGain = this.ctx.createGain();
    lfo.frequency.value = 0.5;
    lfoGain.gain.value = 100;
    lfo.connect(lfoGain);
    lfoGain.connect(this.musicFilter.frequency);
    lfo.start();

    this.musicOsc.connect(this.musicFilter);
    this.musicFilter.connect(this.musicGainNode);
    this.musicOsc.start();
  }

  public stopMusic() {
    if (this.musicOsc) {
      this.musicOsc.stop();
      this.musicOsc = null;
    }
  }

  public resume() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public playStackSound(score: number, isPerfect: boolean) {
    if (!this.ctx || !this.gainNode) return;
    this.resume();

    const octave = Math.floor(score / 8);
    const noteIndex = score % 8;
    const scale = [0, 2, 4, 5, 7, 9, 11, 12]; // Major scale for more variety
    const baseFreq = 110.00; // A2 - Deeper base
    const frequency = baseFreq * Math.pow(2, octave + scale[noteIndex] / 12);

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const noise = this.ctx.createBufferSource();
    const noiseGain = this.ctx.createGain();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();

    // Create a bit of noise for the "hit"
    const bufferSize = this.ctx.sampleRate * 0.05;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
    noise.buffer = buffer;

    osc.type = isPerfect ? 'triangle' : 'sawtooth';
    osc.frequency.setValueAtTime(frequency, now);
    
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(frequency * 1.01, now); // Slight detune

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(isPerfect ? 3000 : 1500, now);
    filter.Q.setValueAtTime(isPerfect ? 10 : 2, now);
    filter.frequency.exponentialRampToValueAtTime(200, now + 0.5);

    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(isPerfect ? 0.5 : 0.3, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + (isPerfect ? 1.2 : 0.6));

    noiseGain.gain.setValueAtTime(0.2, now);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);

    osc.connect(filter);
    osc2.connect(filter);
    noise.connect(noiseGain);
    noiseGain.connect(filter);
    filter.connect(gain);
    gain.connect(this.gainNode);

    osc.start(now);
    osc2.start(now);
    noise.start(now);
    osc.stop(now + 1.5);
    osc2.stop(now + 1.5);
  }

  public playStartSound() {
    if (!this.ctx || !this.gainNode) return;
    this.resume();
    const now = this.ctx.currentTime;
    
    const freqs = [220, 330, 440, 660];
    freqs.forEach((f, i) => {
        const osc = this.ctx!.createOscillator();
        const g = this.ctx!.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, now + i * 0.1);
        g.gain.setValueAtTime(0, now + i * 0.1);
        g.gain.linearRampToValueAtTime(0.1, now + i * 0.1 + 0.05);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.1 + 0.5);
        osc.connect(g);
        g.connect(this.gainNode!);
        osc.start(now + i * 0.1);
        osc.stop(now + i * 0.1 + 0.6);
    });
  }

  public playGameOver() {
    if (!this.ctx || !this.gainNode) return;
    this.resume();

    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    const filter = this.ctx.createBiquadFilter();
    
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(200, now);
    osc.frequency.exponentialRampToValueAtTime(30, now + 2);

    osc2.type = 'square';
    osc2.frequency.setValueAtTime(100, now);
    osc2.frequency.exponentialRampToValueAtTime(20, now + 2);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(2000, now);
    filter.frequency.linearRampToValueAtTime(100, now + 1.5);

    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 2.5);

    osc.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(this.gainNode);

    osc.start(now);
    osc2.start(now);
    osc.stop(now + 2.5);
    osc2.stop(now + 2.5);
  }
}

export const audioManager = new AudioEngine();